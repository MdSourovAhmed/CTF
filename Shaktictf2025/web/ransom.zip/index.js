const http = require("http");
const { scryptSync, createDecipheriv } = require("crypto");
const { readFileSync } = require("fs");
const cache = {};
const operators = {
  "@": [
    18,
    (stack) => {
      let a = stack.pop(),
        b = stack.pop();
      // b.evaluate(a) // THIS IS ACTUALLY VULNERABLE! SO I COMMENTED IT OUT HAHAHAHA! NOW YOU CAN'T FREE YOUR WAIFU ANYMORE!
      return null;
    },
  ],
  $: [
    18,
    (stack) => {
      let code = stack.pop();
      return (cache[code] ||= parseLogicExpression(code));
    },
  ],
  "$=": [
    19,
    (stack) => {
      let a = stack.pop(),
        b = stack.pop(),
        c = stack.pop();
      if ("__proto__" === b) return null; // no naughty!
      return (c[b] = a);
    },
  ],
  ".": [
    17,
    (stack) => {
      let a = stack.pop(),
        b = stack.pop();
      if ("__proto__" === a) return null; // no naughty!
      return b[a];
    },
  ],
  "#": [16, (stack) => stack.pop().charCodeAt(0)],
  "!": [14, (stack) => !stack.pop()],
  "%": [
    12,
    (stack) => {
      let a = stack.pop(),
        b = stack.pop();
      return b % a;
    },
  ],
  "*": [12, (stack) => stack.pop() * stack.pop()],
  "/": [12, (stack) => 1 / (stack.pop() / stack.pop())],
  "+": [11, (stack) => stack.pop() + stack.pop()],
  "-": [11, (stack) => -(stack.pop() - stack.pop())],
  "<": [
    9,
    (stack) => {
      let a = stack.pop(),
        b = stack.pop();
      if (!isNaN(a) && !isNaN(b)) return b < a;
      return b.localeCompare(a);
    },
  ],
  ">": [
    9,
    (stack) => {
      let a = stack.pop(),
        b = stack.pop();
      if (!isNaN(a) && !isNaN(b)) return b > a;
      return a.localeCompare(b);
    },
  ],
  "==": [8, (stack) => stack.pop() === stack.pop()],
  "!=": [8, (stack) => stack.pop() !== stack.pop()],
  "&": [7, (stack) => stack.pop() & stack.pop()],
  "^": [6, (stack) => stack.pop() ^ stack.pop()],
  "|": [5, (stack) => stack.pop() | stack.pop()],
  "&&": [4, (stack) => stack.pop() && stack.pop()],
  "||": [3, (stack) => stack.pop() || stack.pop()],
};
function isOp(token) {
  return operators[token];
}
function getPrecedence(op) {
  return operators[op][0];
}
function isMOp(expression, index) {
  const op = expression.slice(index, index + 2);
  if (isOp(op)) return op;
  return undefined;
}
function isStrLit(val) {
  return (
    (val[0] === '"' && val[val.length - 1] === '"') ||
    (val[0] === "'" && val[val.length - 1] === "'")
  );
}
function isLiteral(val) {
  const lowerVal = val.toLowerCase();
  if (lowerVal === "true") return true;
  if (lowerVal === "false") return false;
  if (!isNaN(lowerVal)) return parseInt(lowerVal);
  if (isStrLit(val)) return val;
  return undefined;
}
function parseLogicExpression(expression) {
  expression = expression.replace("__proto__", ""); // no naughty!
  const vars = new Set();
  const queue = [];
  const stack = [];
  let cVar = "";

  const flushCVar = () => {
    if (!cVar) return;
    const lit = isLiteral(cVar);
    if (lit !== undefined) {
      queue.push(lit);
    } else {
      vars.add(cVar);
      queue.push(cVar);
    }
    cVar = "";
  };

  for (let i = 0; i < expression.length; i++) {
    const char = expression[i];
    if (/\s/.test(char)) continue;
    if (char === '"' || char === "'") {
      flushCVar();
      const quoteChar = char;
      let literal = char;
      i++;
      while (i < expression.length && expression[i] !== quoteChar) {
        literal += expression[i];
        i++;
      }
      if (i < expression.length) literal += expression[i];
      queue.push(literal);
      continue;
    }

    const mop = isMOp(expression, i);
    if (mop) {
      flushCVar();
      i++;
      while (
        stack.length > 0 &&
        isOp(stack[stack.length - 1]) &&
        getPrecedence(stack[stack.length - 1]) >= getPrecedence(mop)
      )
        queue.push(stack.pop());
      stack.push(mop);
    } else if (/[a-zA-Z0-9]/.test(char)) {
      cVar += char;
    } else {
      flushCVar();
      if (char === "(") {
        stack.push(char);
      } else if (char === ")") {
        while (stack.length && stack[stack.length - 1] !== "(")
          queue.push(stack.pop());
        stack.pop();
      } else if (isOp(char)) {
        while (
          stack.length > 0 &&
          isOp(stack[stack.length - 1]) &&
          getPrecedence(stack[stack.length - 1]) >= getPrecedence(char)
        )
          queue.push(stack.pop());
        stack.push(char);
      }
    }
  }

  flushCVar();
  while (stack.length) queue.push(stack.pop());
  const variables = Array.from(vars);
  const evaluate = (...input) => {
    const st = [];
    queue.forEach((token) => {
      if (typeof token === "string") {
        if (isStrLit(token)) {
          st.push(token.slice(1, -1));
        } else if (isOp(token)) {
          st.push(operators[token][1](st));
        } else {
          st.push(input[variables.indexOf(token)]);
        }
      } else {
        st.push(token);
      }
    });
    return st.pop();
  };
  return { variables, queue, evaluate };
}

const ENC = readFileSync("waifu.bin");
const INDEX = readFileSync("./index.html");
const RANSOM = readFileSync("./ransomware.js");

function image(password) {
  const ALGO = "aes-256-gcm";
  const SALT_LEN = 16;
  const IV_LEN = 12;
  const key = scryptSync(password, ENC.slice(0, SALT_LEN), 32);
  const decipher = createDecipheriv(
    ALGO,
    key,
    ENC.slice(SALT_LEN, SALT_LEN + IV_LEN)
  );
  decipher.setAuthTag(ENC.slice(SALT_LEN + IV_LEN, SALT_LEN + IV_LEN + 16));
  return Buffer.concat([
    decipher.update(ENC.slice(SALT_LEN + IV_LEN + 16)),
    decipher.final(),
  ]);
}

http
  .createServer(function (req, res) {
    if (req.method === "GET") {
      if (req.url === "/ransomware.js") {
        res.writeHead(200, { "Content-Type": "application/javascript" });
        res.end(RANSOM);
        return;
      }
      res.writeHead(200).end(INDEX);
      return;
    }
    try {
      const password = req.headers["authorization"];
      if (!password) {
        res.writeHead(401).end("Unauthorized");
        return;
      }
      // mwahahaha! I am so evil! There is ZERO chance you can guess a UUID!
      if (
        parseLogicExpression(
          `"${password}" == "${crypto.randomUUID()}"`
        ).evaluate()
      ) {
        res.writeHead(200, { "Content-Type": "image/jpeg" });
        res.end(image(process.env.FLAG || "wwf{this_is_not_a_flag}"), "binary");
      } else {
        res.writeHead(401).end("Unauthorized");
        return;
      }
    } catch (e) {
      console.error(e);
      res.writeHead(500).end("Internal Server Error");
    }
  })
  .listen(8080);
