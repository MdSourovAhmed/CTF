package main

import (
	"net/http"

	"deadroute/controllers"
	"deadroute/models"
)

func SetupRoutes() *models.Router {
	r := models.MakeRouter()

	// Register middleware
	r.UseMiddleware(models.LogMiddleware)
	r.UseMiddleware(models.AntiXSS)
	r.UseMiddleware(models.CSPProtection)

	// Initialize controllers
	authController := controllers.NewAuthController()
	adminController := controllers.NewAdminController()
	noteController := controllers.NewNoteController()

	// Static files
	r.ServeStatic("/static/", "src/views/static/")

	// Public routes
	r.Get("/", http.HandlerFunc(noteController.PublicNotesPage))
	r.Get("/notes", http.HandlerFunc(noteController.PublicListNotes))
	r.Get("/notes/read", http.HandlerFunc(noteController.PublicReadNote))
	r.Get("/login", http.HandlerFunc(authController.LoginPage))
	r.Post("/login", http.HandlerFunc(authController.Login))
	r.Get("/logout", http.HandlerFunc(authController.Logout))

	// Protected admin routes
	r.Get("/admin", models.RequireAuth, http.HandlerFunc(adminController.Dashboard))
	r.Get("/admin/notes", models.RequireAuth, http.HandlerFunc(noteController.ListNotes))
	r.Post("/admin/notes", models.RequireAuth, http.HandlerFunc(noteController.WriteNote))
	r.Get("/admin/login-token", models.LocalHostOnly, http.HandlerFunc(adminController.LoginToken))

	// Note operations with ID via query parameter
	r.Get("/admin/notes/read", models.RequireAuth, http.HandlerFunc(noteController.ReadNote))
	r.Get("/admin/notes/delete", models.RequireAuth, http.HandlerFunc(noteController.DeleteNote))

	return r
}
