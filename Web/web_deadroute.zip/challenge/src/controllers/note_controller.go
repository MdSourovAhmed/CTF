package controllers

import (
	"encoding/json"
	"fmt"
	"html/template"
	"io/ioutil"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"

	"deadroute/models"
)

type NoteController struct {
	notesDir string
}

func NewNoteController() *NoteController {
	notesDir := "notes"
	os.MkdirAll(notesDir, 0755)
	return &NoteController{notesDir: notesDir}
}

type Note struct {
	ID      string `json:"id"`
	Title   string `json:"title"`
	Content string `json:"content"`
	Date    string `json:"date"`
}

func (c *NoteController) ListNotes(w http.ResponseWriter, r *http.Request) {
	if !models.CheckAuth(w, r) {
		return
	}
	files, err := ioutil.ReadDir(c.notesDir)
	if err != nil {
		http.Error(w, "Error reading notes directory", http.StatusInternalServerError)
		return
	}

	notes := []Note{}
	for _, file := range files {
		if file.IsDir() {
			continue
		}

		content, err := ioutil.ReadFile(filepath.Join(c.notesDir, file.Name()))
		if err != nil {
			continue
		}

		// Parse note file format: first line is title, rest is content
		lines := strings.SplitN(string(content), "\n", 2)
		title := file.Name()
		noteContent := ""
		if len(lines) > 0 {
			title = strings.TrimPrefix(lines[0], "TITLE: ")
			if len(lines) > 1 {
				noteContent = lines[1]
			}
		}

		noteID := file.Name()
		notes = append(notes, Note{
			ID:      noteID,
			Title:   title,
			Content: noteContent,
			Date:    file.ModTime().Format("2006-01-02 15:04:05"),
		})
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(notes)
}

func (c *NoteController) ReadNote(w http.ResponseWriter, r *http.Request) {
	if !models.CheckAuth(w, r) {
		return
	}
	// Extract note ID from query parameter
	noteID := r.URL.Query().Get("id")
	if noteID == "" {
		// Try to extract from path as fallback
		path := r.URL.Path
		parts := strings.Split(path, "/")
		if len(parts) >= 4 {
			noteID = parts[len(parts)-1]
		}
	}

	if noteID == "" {
		http.Error(w, "Invalid note ID", http.StatusBadRequest)
		return
	}

	// Sanitize noteID to prevent directory traversal
	noteID = strings.ReplaceAll(noteID, "../", "")

	filePath := filepath.Join(c.notesDir, noteID)
	content, err := ioutil.ReadFile(filePath)
	if err != nil {
		http.Error(w, "Note not found", http.StatusNotFound)
		return
	}

	// Parse note file
	lines := strings.SplitN(string(content), "\n", 2)
	title := noteID
	noteContent := ""
	if len(lines) > 0 {
		title = strings.TrimPrefix(lines[0], "TITLE: ")
		if len(lines) > 1 {
			noteContent = lines[1]
		}
	}

	note := Note{
		ID:      noteID,
		Title:   title,
		Content: noteContent,
		Date:    time.Now().Format("2006-01-02 15:04:05"),
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(note)
}

func (c *NoteController) WriteNote(w http.ResponseWriter, r *http.Request) {
	if !models.CheckAuth(w, r) {
		return
	}
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	var note Note
	err := json.NewDecoder(r.Body).Decode(&note)
	if err != nil {
		http.Error(w, "Invalid JSON", http.StatusBadRequest)
		return
	}

	// Generate note ID if not provided
	if note.ID == "" {
		note.ID = fmt.Sprintf("note_%d", time.Now().Unix())
	}

	// Sanitize noteID
	note.ID = strings.ReplaceAll(note.ID, "../", "")

	// Format note content: TITLE: <title>\n<content>
	noteContent := fmt.Sprintf("TITLE: %s\n%s", note.Title, note.Content)

	filePath := filepath.Join(c.notesDir, note.ID)
	err = ioutil.WriteFile(filePath, []byte(noteContent), 0644)
	if err != nil {
		http.Error(w, "Error writing note", http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{"status": "success", "id": note.ID})
}

func (c *NoteController) DeleteNote(w http.ResponseWriter, r *http.Request) {
	if !models.CheckAuth(w, r) {
		return
	}
	// Allow both DELETE and GET (for simplicity)
	if r.Method != http.MethodDelete && r.Method != http.MethodGet {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	// Extract note ID from query parameter
	noteID := r.URL.Query().Get("id")
	if noteID == "" {
		// Try to extract from path as fallback
		path := r.URL.Path
		parts := strings.Split(path, "/")
		if len(parts) >= 4 {
			noteID = parts[len(parts)-1]
		}
	}

	if noteID == "" {
		http.Error(w, "Invalid note ID", http.StatusBadRequest)
		return
	}

	// Sanitize noteID
	noteID = strings.ReplaceAll(noteID, "../", "")

	filePath := filepath.Join(c.notesDir, noteID)
	err := os.Remove(filePath)
	if err != nil {
		http.Error(w, "Note not found", http.StatusNotFound)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{"status": "success"})
}

// PublicListNotes returns notes as JSON without authentication requirement
func (c *NoteController) PublicListNotes(w http.ResponseWriter, r *http.Request) {
	files, err := ioutil.ReadDir(c.notesDir)
	if err != nil {
		http.Error(w, "Error reading notes directory", http.StatusInternalServerError)
		return
	}

	notes := []Note{}
	for _, file := range files {
		if file.IsDir() {
			continue
		}

		content, err := ioutil.ReadFile(filepath.Join(c.notesDir, file.Name()))
		if err != nil {
			continue
		}

		// Parse note file format: first line is title, rest is content
		lines := strings.SplitN(string(content), "\n", 2)
		title := file.Name()
		noteContent := ""
		if len(lines) > 0 {
			title = strings.TrimPrefix(lines[0], "TITLE: ")
			if len(lines) > 1 {
				noteContent = lines[1]
			}
		}

		noteID := file.Name()
		notes = append(notes, Note{
			ID:      noteID,
			Title:   title,
			Content: noteContent,
			Date:    file.ModTime().Format("2006-01-02 15:04:05"),
		})
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(notes)
}

// PublicReadNote reads a note without authentication requirement
func (c *NoteController) PublicReadNote(w http.ResponseWriter, r *http.Request) {
	// Extract note ID from query parameter
	noteID := r.URL.Query().Get("id")
	if noteID == "" {
		// Try to extract from path as fallback
		path := r.URL.Path
		parts := strings.Split(path, "/")
		if len(parts) >= 3 {
			noteID = parts[len(parts)-1]
		}
	}

	if noteID == "" {
		http.Error(w, "Invalid note ID", http.StatusBadRequest)
		return
	}

	// Sanitize noteID to prevent directory traversal
	if strings.Contains(noteID, "..") {
		http.Error(w, "Invalid note ID", http.StatusBadRequest)
		return
	}

	filePath := filepath.Join(c.notesDir, noteID)
	content, err := ioutil.ReadFile(filePath)
	if err != nil {
		http.Error(w, "Note not found", http.StatusNotFound)
		return
	}

	// Parse note file
	lines := strings.SplitN(string(content), "\n", 2)
	title := noteID
	noteContent := ""
	if len(lines) > 0 {
		title = strings.TrimPrefix(lines[0], "TITLE: ")
		if len(lines) > 1 {
			noteContent = lines[1]
		}
	}

	// Get file modification time
	fileInfo, err := os.Stat(filePath)
	date := time.Now().Format("2006-01-02 15:04:05")
	if err == nil {
		date = fileInfo.ModTime().Format("2006-01-02 15:04:05")
	}

	note := Note{
		ID:      noteID,
		Title:   title,
		Content: noteContent,
		Date:    date,
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(note)
}

// PublicNotesPage renders the homepage with notes display
func (c *NoteController) PublicNotesPage(w http.ResponseWriter, r *http.Request) {
	tmpl, err := template.ParseFiles("src/views/templates/index.html")
	if err != nil {
		http.Error(w, "Error loading template", http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	tmpl.Execute(w, nil)
}
