package controllers

import (
	"html/template"
	"net/http"

	"deadroute/models"
)

type AuthController struct{}

func NewAuthController() *AuthController {
	return &AuthController{}
}

func (c *AuthController) LoginPage(w http.ResponseWriter, r *http.Request) {
	// Check if already authenticated
	cookie, err := r.Cookie("santa_auth")
	if err == nil && models.VerifyAuthToken(cookie.Value) {
		http.Redirect(w, r, "/admin", http.StatusSeeOther)
		return
	}

	tmpl, err := template.ParseFiles("src/views/templates/login.html")
	if err != nil {
		http.Error(w, "Error loading template", http.StatusInternalServerError)
		return
	}

	// Check for error query parameter
	hasError := r.URL.Query().Get("error") == "invalid"

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	tmpl.Execute(w, map[string]bool{"Error": hasError})
}

func (c *AuthController) Login(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	password := r.FormValue("password")
	if models.CheckPassword(password) {
		authToken := models.GenerateAuthToken()
		http.SetCookie(w, &http.Cookie{
			Name:     "santa_auth",
			Value:    authToken,
			Path:     "/",
			MaxAge:   3600, // 1 hour
			HttpOnly: true,
			SameSite: http.SameSiteStrictMode,
			Secure:   false, // Set to true in production with HTTPS
		})
		http.Redirect(w, r, "/admin", http.StatusSeeOther)
		return
	}

	// Invalid password - redirect back to login with error
	http.Redirect(w, r, "/?error=invalid", http.StatusSeeOther)
}

func (c *AuthController) Logout(w http.ResponseWriter, r *http.Request) {
	http.SetCookie(w, &http.Cookie{
		Name:     "santa_auth",
		Value:    "",
		Path:     "/",
		MaxAge:   -1,
		HttpOnly: true,
	})
	http.Redirect(w, r, "/", http.StatusSeeOther)
}
