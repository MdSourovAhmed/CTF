package controllers

import (
	"html/template"
	"net/http"

	"deadroute/models"
)

type AdminController struct{}

func NewAdminController() *AdminController {
	return &AdminController{}
}

func (c *AdminController) Dashboard(w http.ResponseWriter, r *http.Request) {
	tmpl, err := template.ParseFiles("src/views/templates/admin.html")
	if err != nil {
		http.Error(w, "Error loading template", http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	tmpl.Execute(w, nil)
}

func (c *AdminController) LoginToken(w http.ResponseWriter, r *http.Request) {
	token := models.GenerateAuthToken()
	w.Header().Set("Content-Type", "text/plain")
	w.Write([]byte(token))
}
