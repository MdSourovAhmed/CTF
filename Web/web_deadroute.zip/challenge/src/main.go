package main

import "net/http"

func main() {
	r := SetupRoutes()
	http.ListenAndServe(":4445", r)
}
