package models

import (
	"net/http"
	"strings"
	"sync"
)

type Handler interface{}

type Middleware = func(next http.Handler) http.Handler

type Router struct {
	mu     sync.RWMutex
	routes map[string]http.HandlerFunc // key format: "METHOD:path"
	mws    []Middleware
}

func MakeRouter() *Router {
	return &Router{routes: make(map[string]http.HandlerFunc)}
}

func (r *Router) UseMiddleware(mw Middleware) {
	r.mu.Lock()
	r.mws = append(r.mws, mw)
	r.mu.Unlock()
}

func (r *Router) ServeHTTP(w http.ResponseWriter, req *http.Request) {
	r.mu.RLock()
	// Check for static files first
	if strings.HasPrefix(req.URL.Path, "/static/") {
		fs := http.FileServer(http.Dir("src/views/static/"))
		http.StripPrefix("/static/", fs).ServeHTTP(w, req)
		r.mu.RUnlock()
		return
	}

	// Create route key with method and path
	routeKey := req.Method + ":" + req.URL.Path
	h, ok := r.routes[routeKey]
	if !ok {
		// Try without method for backward compatibility
		h, ok = r.routes[req.URL.Path]
	}
	r.mu.RUnlock()
	if ok {
		h.ServeHTTP(w, req)
		return
	}
	http.NotFound(w, req)
}

func (r *Router) ServeStatic(pattern, dir string) {
	// Static files are handled in ServeHTTP
	// This method exists for API compatibility
}

func (r *Router) Handle(pattern string, handlers []Handler) {
	r.mu.Lock()
	r.routes[pattern] = func(w http.ResponseWriter, req *http.Request) {
		r.mu.RLock()
		mws := r.mws
		r.mu.RUnlock()
		for _, h := range handlers {
			mws = append(mws, getMWFromHandler(h))
		}
		h := http.Handler(http.HandlerFunc(func(http.ResponseWriter, *http.Request) {}))
		for i := len(mws) - 1; i >= 0; i-- {
			h = mws[i](h)
		}
		h.ServeHTTP(w, req)
	}
	r.mu.Unlock()
}

func (r *Router) Get(pattern string, h ...Handler) {
	r.mu.Lock()
	routeKey := "GET:" + pattern
	r.routes[routeKey] = func(w http.ResponseWriter, req *http.Request) {
		if req.Method != http.MethodGet {
			http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
			return
		}
		r.mu.RLock()
		mws := r.mws
		r.mu.RUnlock()
		for _, handler := range h {
			mws = append(mws, getMWFromHandler(handler))
		}
		handler := http.Handler(http.HandlerFunc(func(http.ResponseWriter, *http.Request) {}))
		for i := len(mws) - 1; i >= 0; i-- {
			handler = mws[i](handler)
		}
		handler.ServeHTTP(w, req)
	}
	r.mu.Unlock()
}

func (r *Router) Post(pattern string, h ...Handler) {
	r.mu.Lock()
	routeKey := "POST:" + pattern
	r.routes[routeKey] = func(w http.ResponseWriter, req *http.Request) {
		if req.Method != http.MethodPost {
			http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
			return
		}
		r.mu.RLock()
		mws := r.mws
		r.mu.RUnlock()
		for _, handler := range h {
			mws = append(mws, getMWFromHandler(handler))
		}
		handler := http.Handler(http.HandlerFunc(func(http.ResponseWriter, *http.Request) {}))
		for i := len(mws) - 1; i >= 0; i-- {
			handler = mws[i](handler)
		}
		handler.ServeHTTP(w, req)
	}
	r.mu.Unlock()
}

func getMWFromHandler(h Handler) Middleware {
	if mw, ok := h.(func(http.Handler) http.Handler); ok {
		return mw
	}
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			h.(http.Handler).ServeHTTP(w, r)
			next.ServeHTTP(w, r)
		})
	}
}
