package models

import (
	"crypto/hmac"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/hex"
	"os"
)

func getPassword() string {
	expectedPassword := os.Getenv("ADMIN_PASSWORD")
	if expectedPassword == "" {
		panic("ADMIN_PASSWORD is not set")
	}
	return expectedPassword
}

func CheckPassword(password string) bool {
	expectedPassword := getPassword()
	return subtle.ConstantTimeCompare([]byte(password), []byte(expectedPassword)) == 1
}

// GenerateAuthToken creates a secure HMAC token from the password
func GenerateAuthToken() string {
	password := getPassword()
	secret := os.Getenv("AUTH_SECRET")
	if secret == "" {
		panic("AUTH_SECRET is not set")
	}

	mac := hmac.New(sha256.New, []byte(secret))
	mac.Write([]byte(password))
	return hex.EncodeToString(mac.Sum(nil))
}

// VerifyAuthToken verifies that the provided token matches the expected password hash
func VerifyAuthToken(token string) bool {
	expectedToken := GenerateAuthToken()
	return subtle.ConstantTimeCompare([]byte(token), []byte(expectedToken)) == 1
}
